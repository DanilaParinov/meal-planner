# Meal Planner — Контекст для Claude Code

## 📌 Обзор проекта

**Meal Planner** — сервис подбора наборов блюд на основе калорийного лимита.

- **Backend**: Go + Gin Framework + PostgreSQL
- **Frontend**: HTML + CSS + Vanilla JavaScript
- **MVP Status**: Фаза 1 завершена, готов к использованию локально

## 🎯 Текущие задачи / Next Steps

### Фаза 1 ✅ (Завершена)
- [x] Структура Go проекта
- [x] PostgreSQL БД с миграциями
- [x] REST API (5 endpoints)
- [x] Алгоритм подбора (knapsack)
- [x] Frontend (HTML/CSS/JS)
- [x] Docker Compose для локального тестирования

### Фаза 2 (Опционально - можешь пропустить)
- [ ] Кеширование результатов (Redis)
- [ ] Параллельная обработка (goroutines)
- [ ] Поддержка смешанных ресторанов

### Фаза 4 (Когда будешь готов)
- [ ] CLI утилита для анализа фото меню
- [ ] Интеграция Google Vision API
- [ ] Админ-панель для валидации меню

### Deployment
- [ ] Docker контейнеризация
- [ ] Развертывание на Yandex Cloud
- [ ] CI/CD с GitHub Actions

## 📁 Структура кода

```
meal-planner/
├── cmd/server/main.go              ← точка входа
├── internal/
│   ├── api/
│   │   ├── handlers.go            ← HTTP endpoints
│   │   └── middleware.go          ← аутентификация
│   ├── db/
│   │   ├── db.go                  ← подключение БД
│   │   └── queries.go             ← SQL запросы
│   ├── models/models.go           ← structs
│   ├── algorithm/knapsack.go      ← алгоритм
│   └── config/config.go           ← конфиг
├── migrations/                     ← SQL миграции
├── frontend/                       ← UI (HTML/CSS/JS)
└── docker-compose.yml             ← PostgreSQL
```

## 🚀 Как запустить локально

```bash
# 1. PostgreSQL
docker-compose up -d

# 2. Зависимости Go
go mod download

# 3. Сервер
cd cmd/server && go run main.go

# 4. Браузер
http://localhost:8080
```

## 🔑 API ключи для тестирования

```
X-API-Key: test-user-abc123xyz
X-API-Key: test-user-def456uvw
X-API-Key: test-user-ghi789rst
```

## 📊 Основные компоненты

### 1. **Алгоритм подбора** (internal/algorithm/knapsack.go)
- Задача: найти все подмножества блюд, сумма калорий которых ≤ max_calories
- Метод: backtracking с рекурсией
- Результаты отсортированы по близости к максимуму
- Оптимизация: возвращаем top 20 комбинаций

### 2. **API Endpoints**
```
GET  /api/restaurants              ← список ресторанов
POST /api/suggest                  ← подбор блюд по калориям
GET  /api/collections              ← история пользователя
POST /api/collections              ← сохранить набор
```

### 3. **База данных**
- `restaurants` — ресторан
- `meals` — блюда ресторана (с калорийностью)
- `users` — тестовые пользователи (API ключи)
- `meal_collections` — сохраненные наборы пользователя

### 4. **Frontend**
- Две режима: аутентификация + основное приложение
- Реактивный слайдер калорий
- История сохраненных наборов
- Responsive дизайн

## 🔧 Инструменты и зависимости

**Go modules:**
- `github.com/gin-gonic/gin` — HTTP framework
- `github.com/lib/pq` — PostgreSQL driver
- `github.com/joho/godotenv` — .env файлы

**Database:**
- PostgreSQL 15 (в Docker)

**Frontend:**
- Vanilla JavaScript (без фреймворков)
- CSS Grid + Flexbox

## 💡 Советы для Claude Code

### Когда добавляешь новый endpoint:
1. Добавь метод в `internal/api/handlers.go`
2. Зарегистрируй маршрут в `RegisterRoutes()`
3. Протестируй через curl или UI

### Когда добавляешь таблицу в БД:
1. Создай SQL миграцию в `migrations/`
2. Добавь struct в `internal/models/models.go`
3. Добавь query методы в `internal/db/queries.go`

### Когда меняешь алгоритм:
1. Сначала протестируй локально с разными калорийностями
2. Проверь что результаты отсортированы правильно
3. Убедись что не превышаешь max_calories

### Для фронтенда:
- Изменения в `frontend/` автоматически видны при перезагрузке браузера
- API ключ сохраняется в localStorage
- История загружается автоматически

## 🐛 Частые ошибки

| Ошибка | Причина | Решение |
|--------|---------|---------|
| Cannot connect to database | PostgreSQL не запущен | `docker-compose up -d` |
| migration failed | Папка migrations не найдена | Убедись что работаешь из корня `meal-planner/` |
| 401 Unauthorized | Неправильный API ключ | Проверь X-API-Key в header'е |
| Port 5432 already in use | Другой контейнер занял порт | Используй `5433:5432` в docker-compose.yml |

## 🎓 Что можешь улучшить

### Easy (1-2 часа):
- [ ] Добавить новые рестораны и блюда
- [ ] Изменить дизайн фронтенда
- [ ] Добавить сортировку результатов по цене

### Medium (3-5 часов):
- [ ] Фильтр по ингредиентам
- [ ] Поиск по названию блюда
- [ ] Экспорт меню в JSON

### Hard (6+ часов):
- [ ] Поддержка смешанных ресторанов
- [ ] Кеширование результатов (Redis)
- [ ] Пайплайн анализа фото меню

## 📞 Когда нужна помощь Claude Code

**Используй Claude Code для:**
- Генерирования кода (новые endpoints, queries)
- Исправления багов (скопируй ошибку и попроси исправить)
- Добавления фичей (напиши что хочешь, Claude Code сделает)
- Рефактора кода (попроси улучшить, Claude Code предложит дифф)

**Пример промпта для Claude Code:**
```
Добавь в API эндпоинт для получения информации о конкретном ресторане.
Endpoint: GET /api/restaurants/:id
Должен возвращать ресторан + все блюда
```

## 🚀 Команды Claude Code

```bash
# Начать новый разговор
Ctrl+N (Windows/Linux) или Cmd+N (Mac)

# Переключиться между фокусом на код и промптом
Ctrl+Esc (Windows/Linux) или Cmd+Esc (Mac)

# Просмотреть доступные команды
Cmd+Shift+P (Mac) или Ctrl+Shift+P (Windows/Linux)
→ Claude Code
```

---

**Status:** 🟢 Готов к разработке  
**Last Updated:** 2024-01-15  
**Environment:** localhost:8080  
**Database:** PostgreSQL 15 (Docker)
